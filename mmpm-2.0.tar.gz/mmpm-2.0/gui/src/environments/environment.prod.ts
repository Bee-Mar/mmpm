export const environment = {
  production: true,
  assetsPath: "static/assets"
};
