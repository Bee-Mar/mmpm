#!/bin/bash

python3 setup.py requirements init_files init_db install --user
