#!/bin/bash

cd gui && ng serve
